<?php
/**
 * Created by PhpStorm.
 * User: Jonathan Troiano <jonathan.troiano@itsoninc.com>
 * Date: 7/15/14
 * Time: 5:07 PM
 */
return array(
  "tok-Minutes_Abbreviation" => "mins",
  "tok-Texts" => "texts",
  "tok-Data_MB" => "MB",
  "tok-On" => "ON",
  "tok-Off" => "OFF"
);
