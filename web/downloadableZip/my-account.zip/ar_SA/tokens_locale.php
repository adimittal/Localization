<?php
/**
 * Created by PhpStorm.
 * User: Jonathan Troiano <jonathan.troiano@itsoninc.com>
 * Date: 7/15/14
 * Time: 5:07 PM
 */
return array(
  "tok-Minutes_Abbreviation" => "دقائق",
  "tok-Texts" => "رسائل",
  "tok-Data_MB" => "ميجا",
  "tok-On" => "تشغيل ",
  "tok-Off" => "إيقاف"
);
