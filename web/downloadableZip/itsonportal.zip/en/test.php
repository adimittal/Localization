<?php

return array(
"hi"=>"this is a test",
"ohhi"=>"oh hi, this is a test",

);
