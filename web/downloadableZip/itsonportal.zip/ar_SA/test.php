<?php

return array(
  'somekey' => 'this is a test resource'
);